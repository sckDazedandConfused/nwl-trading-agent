"""
token_manager.py
Keeps Schwab OAuth tokens fresh and persisted locally.

Public API:
- get_access_token() -> str
- refresh_access_token() -> str
- load_tokens() -> dict | None
"""
from __future__ import annotations

import json
import os
import tempfile
import time
from pathlib import Path
from typing import Any, Dict, Optional

import requests

from config import settings  # expects .require() to be called by entrypoint

TOKEN_FILE = Path(__file__).with_name("marketdata_token.json")
TOKEN_URL = "https://api.schwabapi.com/v1/oauth/token"
# Refresh a bit early to avoid edge cases around server/client clock skew
CLOCK_SKEW_SECS = 90

# --- file helpers ------------------------------------------------------------

def _atomic_write(path: Path, data: str) -> None:
    """Write to a temp file then replace: prevents partial/tearing writes."""
    tmp_fd, tmp_path = tempfile.mkstemp(dir=str(path.parent), prefix=path.name, text=True)
    try:
        with os.fdopen(tmp_fd, "w", encoding="utf-8") as f:
            f.write(data)
        os.replace(tmp_path, path)
    finally:
        try:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
        except Exception:
            pass

def _now() -> int:
    return int(time.time())

def _save(tokens: Dict[str, Any]) -> None:
    # Derive expires_at with skew
    expires_in = int(tokens.get("expires_in", 1800))
    tokens["expires_at"] = _now() + max(0, expires_in - CLOCK_SKEW_SECS)
    _atomic_write(TOKEN_FILE, json.dumps(tokens, indent=2, sort_keys=True))

def load_tokens() -> Optional[Dict[str, Any]]:
    if not TOKEN_FILE.exists():
        return None
    try:
        return json.loads(TOKEN_FILE.read_text(encoding="utf-8"))
    except Exception:
        return None

def _is_valid(tokens: Optional[Dict[str, Any]]) -> bool:
    return bool(tokens) and _now() < int(tokens.get("expires_at", 0))

# --- http/refresh ------------------------------------------------------------

def _auth_headers_basic() -> Dict[str, str]:
    from base64 import b64encode
    cid = settings.SCHWAB_CLIENT_ID
    csec = settings.SCHWAB_CLIENT_SECRET
    basic = b64encode(f"{cid}:{csec}".encode("utf-8")).decode("ascii")
    return {
        "Content-Type": "application/x-www-form-urlencoded",
        "Authorization": f"Basic {basic}",
        "Accept": "application/json",
    }

def _post_form(url: str, data: Dict[str, Any], timeout: int = 30) -> requests.Response:
    return requests.post(url, data=data, headers=_auth_headers_basic(), timeout=timeout)

def _refresh(refresh_token: str) -> Optional[Dict[str, Any]]:
    if not refresh_token:
        return None
    payload = {
        "grant_type": "refresh_token",
        "refresh_token": refresh_token,
        "redirect_uri": settings.SCHWAB_REDIRECT_URI,
    }
    try:
        resp = _post_form(TOKEN_URL, payload)
    except requests.RequestException as e:
        # Network/timeout error
        return None
    if resp.status_code != 200:
        # Do not log raw body (could include sensitive info)
        return None
    try:
        tok = resp.json()
    except ValueError:
        return None

    # Some providers rotate refresh tokens; persist if present
    if tok.get("refresh_token"):
        # keep the latest refresh token
        pass
    else:
        tok["refresh_token"] = refresh_token

    _save(tok)
    return tok

# --- public API --------------------------------------------------------------

def get_access_token() -> str:
    """
    Return a usable access token, refreshing from disk if expired.
    Raises RuntimeError if no token can be produced.
    """
    tokens = load_tokens()
    if not tokens:
        raise RuntimeError("[token_manager] No token file found; run initial OAuth flow.")
    if _is_valid(tokens):
        return str(tokens["access_token"])

    tokens = _refresh(tokens.get("refresh_token", ""))
    if tokens and tokens.get("access_token"):
        return str(tokens["access_token"])
    raise RuntimeError("[token_manager] Unable to refresh token")

def refresh_access_token() -> str:
    """
    Force a refresh using the stored refresh_token. Returns the new access token.
    Useful when the API returns 401 and the caller wants to retry once.
    """
    tokens = load_tokens()
    if not tokens:
        raise RuntimeError("[token_manager] No token file found; run initial OAuth flow.")
    refreshed = _refresh(tokens.get("refresh_token", ""))
    if refreshed and refreshed.get("access_token"):
        return str(refreshed["access_token"])
    raise RuntimeError("[token_manager] Token refresh failed")
